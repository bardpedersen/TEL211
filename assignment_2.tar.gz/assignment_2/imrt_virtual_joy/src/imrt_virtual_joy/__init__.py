#!/usr/bin/env python3
from .gamepad import main